package com.fd;

public class oneplus extends Mobile{

	@Override
	public double getTax() {
		return 7;
		
	}

}
